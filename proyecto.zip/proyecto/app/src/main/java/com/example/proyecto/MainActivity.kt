package com.example.proyecto

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ComposeCompilerApi
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyecto.ui.theme.ProyectoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            preview()
        }
    }
}

@Composable
fun figma2android() {
    //columna para colocar todas las cosas bien una debajo de otra
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(//dentro de las columnas hay cajas como en html , esta caja es solo el color ese grande que hay
            modifier = Modifier
                .width(372.dp)
                .height(400.dp)
                .padding(0.dp, 10.dp, 0.dp, 0.dp)

                .clip(
                    RoundedCornerShape(
                        topStart = 50.dp,
                        topEnd = 50.dp,
                        bottomStart = 50.dp,
                        bottomEnd = 50.dp
                    )
                )

                .background(
                    Color(
                        red = 0.970833420753479f,
                        green = 0.6043438911437988f,
                        blue = 0.9341843128204346f,
                        alpha = 1f
                    )
                )
        )
        Text(
            text = "Descrubre Tu",
            textAlign = TextAlign.Start,
            fontSize = 30.sp,
            textDecoration = TextDecoration.None,
            letterSpacing = 0.sp,

            overflow = TextOverflow.Ellipsis,
            modifier = Modifier

                .width(190.dp)
                //.height(38.dp)

                .alpha(1f),
            color = Color(red = 0.2750000059604645f, green = 0.26743754744529724f, blue = 0.26743754744529724f, alpha = 1f),
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Normal,
        )
        Text(
            text = "     Propio Lugar",
            textAlign = TextAlign.Start,
            fontSize = 30.sp,
            textDecoration = TextDecoration.None,
            letterSpacing = 0.sp,

            overflow = TextOverflow.Ellipsis,
            modifier = Modifier

                .width(258.dp)

                //.height(38.dp)

                .alpha(1f),
            color = Color(red = 0.2750000059604645f, green = 0.26743754744529724f, blue = 0.26743754744529724f, alpha = 1f),
            fontWeight = FontWeight.Bold,
            fontStyle = FontStyle.Normal,
        )
        Text(
            text = "Desde aqui podrás descrubirar un nuevo mundo al alcance de tu mano. No dudes en registrarte y formar parte de esta nueva gran comunidad de fiesteros, te esperamos",
            textAlign = TextAlign.Center,
            fontSize = 13.sp,
            textDecoration = TextDecoration.None,
            letterSpacing = 0.sp,

            overflow = TextOverflow.Ellipsis,

            color = Color(red = 0f, green = 0f, blue = 0f, alpha = 1f),
            fontWeight = FontWeight.Light,
            fontStyle = FontStyle.Normal,

            modifier = Modifier

                .width(332.dp)
                .padding(0.dp, 10.dp, 0.dp, 10.dp)
                //.height(66.dp)

                .alpha(1f),
        )

        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(0.dp, 20.dp, 0.dp, 0.dp), horizontalArrangement = Arrangement.Center) {
            Box(
                modifier = Modifier
                    .width(170.dp)
                    .height(65.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 15.dp,
                            topEnd = 0.dp,
                            bottomStart = 15.dp,
                            bottomEnd = 0.dp
                        )
                    )


                    .background(
                        Color(
                            red = 0.970833420753479f,
                            green = 0.6043438911437988f,
                            blue = 0.9341843128204346f,
                            alpha = 1f
                        )
                    )
            ){
                Text(
                    text = "Sign in",
                    textAlign = TextAlign.Center,
                    fontSize = 22.sp,
                    textDecoration = TextDecoration.None,
                    letterSpacing = 0.sp,

                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier

                        .width(200.dp)
                        .padding(0.dp, 15.dp, 0.dp, 0.dp)
                        .alpha(1f),
                    color = Color(red = 1f, green = 1f, blue = 1f, alpha = 1f),
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Normal,
                )

            }
            Box(
                modifier = Modifier
                    .width(155.dp)
                    .height(65.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 0.dp,
                            topEnd = 15.dp,
                            bottomStart = 0.dp,
                            bottomEnd = 15.dp
                        )
                    )


                    .background(
                        Color(
                            red = 0.9541666507720947f,
                            green = 0.9541666507720947f,
                            blue = 0.9541666507720947f,
                            alpha = 1f
                        )
                    )
            ){


                Text(
                    text = "Register",
                    textAlign = TextAlign.Center,
                    fontSize = 22.sp,
                    textDecoration = TextDecoration.None,
                    letterSpacing = 0.sp,

                    overflow = TextOverflow.Ellipsis,

                    color = Color(red = 0.3291666805744171f, green = 0.31737157702445984f, blue = 0.31737157702445984f, alpha = 1f),
                    fontWeight = FontWeight.SemiBold,
                    fontStyle = FontStyle.Normal,
                    modifier = Modifier

                        .width(160.dp)
                        .padding(0.dp, 15.dp, 0.dp, 0.dp)
                        //.height(28.dp)

                        .alpha(1f),
                )

            }
        }

    }


}


@Preview(showSystemUi = true)
@Composable
fun preview(){
    figma2android()
}



