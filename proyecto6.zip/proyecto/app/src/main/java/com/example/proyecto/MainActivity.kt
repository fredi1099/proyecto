package com.example.proyecto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.proyecto.ui.theme.ProyectoTheme

sealed class Screen(val ruta: String) {
    object EntrarRegistrar : Screen("EntrarRegistrar")
    object registrarse : Screen("registrarse")
    object sign_in : Screen("sign_in")


}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            navegacion()
        }
    }
}
@Composable
fun navegacion(){
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = Screen.EntrarRegistrar.ruta) {
        composable(Screen.EntrarRegistrar.ruta) {
            EntrarRegistrar(navController = navController)
        }
        composable(Screen.registrarse.ruta) {
            registrarse(navController = navController)
        }
        composable(Screen.sign_in.ruta) {
            sign_in(navController = navController)
        }
    }
}
@Preview
@Composable
fun preview(){
     navegacion()
}